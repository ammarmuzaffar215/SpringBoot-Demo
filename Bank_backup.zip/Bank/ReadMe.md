
Sample Bank customer creation JSON 
{
  "icNumber": "IC1233456789",
  "lastname": "Tan",
  "surname": "Ahmad",
  "description": "New customer registration"
}

Sample Bank account creation JSON 
{
  "accountNumber": "ACC123456789",
  "balance": 2500.75,
  "creationDate": "2025-07-06T14:20:00",
  "customerEntity": {
    "customerID": 1,
    "icNumber": "IC999887766",
    "lastname": "Lim",
    "surname": "Mei Ling",
    "description": "Preferred customer",
    "creationDate": "2025-07-01T09:00:00"
  }
}